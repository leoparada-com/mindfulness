from flask import Flask, render_template, jsonify, request, send_from_directory, Response, url_for
import json
import os
import markdown  # Importar la librería markdown

app = Flask(__name__)

# Cargar los posts desde el archivo JSON
def load_posts():
    with open('posts.json', 'r', encoding='utf-8') as file:
        posts = json.load(file)
    return posts

# Ruta principal para mostrar la página con los posts
@app.route('/')
def index():
    posts = load_posts()
    # Seleccionar los últimos tres posts en orden inverso
    recent_posts = list(reversed(posts[-3:]))
    return render_template('index.html', posts=recent_posts)

# Ruta para mostrar un post específico
@app.route('/posts/<int:post_id>')
def show_post(post_id):
    posts = load_posts()
    post = next((item for item in posts if item["id"] == post_id), None)
    if post:
        md_file_path = os.path.join('static', 'blog', post['folder'], post['content_md'])
        with open(md_file_path, 'r', encoding='utf-8') as file:
            md_content = file.read()
        html_content = markdown.markdown(md_content)  # Convertir Markdown a HTML
        return render_template('post.html', title=post['title'], content=html_content)
    return "Post not found", 404

# Ruta para servir el video de forma streaming
@app.route('/video')
def video():
    def generate():
        with open("static/assets/beemind_intro.mp4", "rb") as video_file:
            chunk = video_file.read(1024)
            while chunk:
                yield chunk
                chunk = video_file.read(1024)
    return Response(generate(), mimetype="video/mp4")

# Ruta para servir las imágenes del post
@app.route('/blog/<folder>/<filename>')
def blog_image(folder, filename):
    return send_from_directory(os.path.join(app.static_folder, 'blog', folder), filename)

# Ruta para servir los archivos estáticos (CSS, JS, imágenes, etc.)
@app.route('/static/<path:filename>')
def custom_static(filename):
    return send_from_directory(app.static_folder, filename)

if __name__ == '__main__':
    app.run(debug=True)

