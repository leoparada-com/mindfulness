// Mostrar el preloader al cargar la página
window.addEventListener('load', function() {
    const preloader = document.getElementById('preloader');
    preloader.style.display = 'none'; // Ocultar el preloader una vez que la página está completamente cargada
});

// Funcionalidad del menú hamburguesa para dispositivos móviles
document.querySelector('.menu-toggle').addEventListener('click', function() {
    const navMenu = document.querySelector('.nav-menu');
    navMenu.classList.toggle('show'); // Alternar la clase 'show' para mostrar/ocultar el menú
});

// Smooth Scroll para los enlaces del menú
document.querySelectorAll('.nav-menu a').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
        // Cerrar el menú hamburguesa después de hacer clic en un enlace (solo para dispositivos móviles)
        const navMenu = document.querySelector('.nav-menu');
        navMenu.classList.remove('show');
    });
});

// Mostrar u ocultar el botón "volver arriba" según el desplazamiento
window.addEventListener('scroll', function() {
    const backToTopButton = document.getElementById('backToTop');
    if (window.scrollY > 200) {
        backToTopButton.style.display = 'flex';
    } else {
        backToTopButton.style.display = 'none';
    }
});

// Función para desplazarse suavemente hacia arriba
function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Evento para el botón "volver arriba"
document.getElementById('backToTop').addEventListener('click', scrollToTop);

// Función para habilitar el streaming de video y permitir saltar a diferentes puntos
document.addEventListener('DOMContentLoaded', function() {
    const video = document.querySelector('video');
    if (video) {
        video.addEventListener('loadedmetadata', () => {
            video.controls = true; // Asegurar que los controles estén habilitados
        });
    }
});
